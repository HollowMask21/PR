﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PR_1
{
    public partial class Form1 : Form
    {
        
        
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int side1 = int.Parse(txtSide1.Text);
                int side2 = int.Parse(txtSide2.Text);
                int side3 = int.Parse(txtSide3.Text);

                if (side1 > 0 && side2 > 0 && side3 > 0 && (side1 + side2 > side3) && (side1 + side3 > side2) && (side2 + side3 > side1))
                {
                    string triangleType = TriangleType(side1, side2, side3);
                    TypeTriangleLabel.Text = $"Тип треугольника: {triangleType}";

                    double area = TriangleArea(side1, side2, side3);
                    double perimeter = TrianglePerimeter(side1, side2, side3);

                    AreaLabel.Text = $"Площадь: {area:F2}";
                    PerimeterLabel.Text = $"Периметр: {perimeter}";
            }
                else
            {
                MessageBox.Show("Треугольника с такими сторонами не существует!");
            }
        }
            catch(FormatException) 
            {
                MessageBox.Show("Пожалуйста, введите корректные целочисленные значения для сторон треугольника");
            }
            catch(Exception ex)
            {
                MessageBox.Show($"Произошла ошибка: {ex.Message}");
            }
        }
        private string TriangleType(int side1, int side2, int side3)
        {
            if (side1 == side2 && side2 == side3)
            {
                return "Равносторонний";
            }
            else if (side1 == side2 || side1 == side3 || side2 == side3)
            {
                return "Равнобедренный";
            }
            else
                return "Разносторонний";
        }
        private double TriangleArea(int side1, int side2, int side3)
        {
            double s = (side1 + side2 + side3) / 2;
            return Math.Sqrt(s * (s - side1) * (s - side2) * (s - side3)); 
        }
        private double TrianglePerimeter(int side1, int side2, int side3)
        {
            return side1 + side2 + side3;
        }
    }
}
