﻿namespace PR_1
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.TypeTriangleLabel = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtSide3 = new System.Windows.Forms.TextBox();
            this.txtSide2 = new System.Windows.Forms.TextBox();
            this.txtSide1 = new System.Windows.Forms.TextBox();
            this.AreaLabel = new System.Windows.Forms.Label();
            this.PerimeterLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(164, 340);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(93, 34);
            this.button1.TabIndex = 17;
            this.button1.Text = "Выполнить";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Bahnschrift Condensed", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(126, 188);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(181, 23);
            this.label6.TabIndex = 14;
            this.label6.Text = "Тип треугольника по углам";
            // 
            // TypeTriangleLabel
            // 
            this.TypeTriangleLabel.AutoSize = true;
            this.TypeTriangleLabel.Font = new System.Drawing.Font("Bahnschrift Condensed", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TypeTriangleLabel.Location = new System.Drawing.Point(116, 154);
            this.TypeTriangleLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.TypeTriangleLabel.Name = "TypeTriangleLabel";
            this.TypeTriangleLabel.Size = new System.Drawing.Size(202, 23);
            this.TypeTriangleLabel.TabIndex = 15;
            this.TypeTriangleLabel.Text = "Тип треугольника по сторонам";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bahnschrift Condensed", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(116, 56);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(205, 23);
            this.label4.TabIndex = 16;
            this.label4.Text = "Введите стороны треугольника";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // txtSide3
            // 
            this.txtSide3.Location = new System.Drawing.Point(275, 104);
            this.txtSide3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtSide3.Name = "txtSide3";
            this.txtSide3.Size = new System.Drawing.Size(85, 20);
            this.txtSide3.TabIndex = 10;
            // 
            // txtSide2
            // 
            this.txtSide2.Location = new System.Drawing.Point(172, 104);
            this.txtSide2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtSide2.Name = "txtSide2";
            this.txtSide2.Size = new System.Drawing.Size(88, 20);
            this.txtSide2.TabIndex = 9;
            // 
            // txtSide1
            // 
            this.txtSide1.Location = new System.Drawing.Point(71, 104);
            this.txtSide1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtSide1.Name = "txtSide1";
            this.txtSide1.Size = new System.Drawing.Size(85, 20);
            this.txtSide1.TabIndex = 8;
            // 
            // AreaLabel
            // 
            this.AreaLabel.AutoSize = true;
            this.AreaLabel.Font = new System.Drawing.Font("Bahnschrift Condensed", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.AreaLabel.Location = new System.Drawing.Point(171, 257);
            this.AreaLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.AreaLabel.Name = "AreaLabel";
            this.AreaLabel.Size = new System.Drawing.Size(67, 23);
            this.AreaLabel.TabIndex = 18;
            this.AreaLabel.Text = "Площадь";
            // 
            // PerimeterLabel
            // 
            this.PerimeterLabel.AutoSize = true;
            this.PerimeterLabel.Font = new System.Drawing.Font("Bahnschrift Condensed", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.PerimeterLabel.Location = new System.Drawing.Point(171, 224);
            this.PerimeterLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.PerimeterLabel.Name = "PerimeterLabel";
            this.PerimeterLabel.Size = new System.Drawing.Size(69, 23);
            this.PerimeterLabel.TabIndex = 19;
            this.PerimeterLabel.Text = "Периметр";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(440, 397);
            this.Controls.Add(this.PerimeterLabel);
            this.Controls.Add(this.AreaLabel);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.TypeTriangleLabel);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtSide3);
            this.Controls.Add(this.txtSide2);
            this.Controls.Add(this.txtSide1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label TypeTriangleLabel;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtSide3;
        private System.Windows.Forms.TextBox txtSide2;
        private System.Windows.Forms.TextBox txtSide1;
        private System.Windows.Forms.Label AreaLabel;
        private System.Windows.Forms.Label PerimeterLabel;
    }
}

